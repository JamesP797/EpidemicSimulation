import random

class Person(object):
    def __init__(self, x, y, speed, wearingMask, xStart, xEnd, infDuration, radius, destinations):
        self._x = x
        self._y = y
        self._speed = speed
        self._state = 'S'
        self._infectedTime = 0;
        self._infectedDuration = infDuration;
        self._radius = radius
        self._travelPoints = []
        self._numPoints = random.randrange(2, destinations)
        self._num_infected = 0
        for n in range(self._numPoints):
            self._travelPoints.append((random.randrange(xStart + 5, xEnd - 15),
                                       random.randrange(0, 340)))
        self._currentDestination = 0;
        self._wearing_mask = wearingMask

    def move(self):
        destX = self._travelPoints[self._currentDestination][0]
        destY = self._travelPoints[self._currentDestination][1]
        dist = ((destX-self._x)**2 + (destY-self._y)**2)**(1/2)
        if (dist == 0):
            dist = 0.001
        self._x += self._speed * ((destX - self._x) / dist)
        self._y += self._speed * ((destY - self._y) / dist)
        if abs(self._x - destX) < 5 and abs(self._y - destY) < 5:
            self._currentDestination = (self._currentDestination + 1) % self._numPoints
        if self._state == 'I':
            self._infectedTime += 1
            if self._infectedTime >= self._infectedDuration:
                self._state = 'R'
                self._num_infected = 0

    def get_coords(self):
        return (self._x, self._y)

    def is_colliding(self, other, infectionChance):
        if abs(self._x - other._x) <= self._radius and abs(self._y - other._y) <= self._radius:
            if (self._wearing_mask):
                infectionChance = 0.15 * infectionChance
            if (random.uniform(0, 1) < infectionChance):
                return True
