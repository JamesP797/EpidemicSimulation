import tkinter as tk

class View(tk.Canvas):
    def __init__(self, master, width, height):
        super().__init__(master, bg='light grey', width=width, height=height,
                         bd=0, highlightthickness=0, relief='ridge')
        self._width = width
        self._height = height
        self._master = master

    def redraw(self, people, regions):
        self.delete(tk.ALL)
        for person in people:
            coords = person.get_coords()
            x = coords[0]
            y = coords[1]
            if person._state == 'I':
                colour = 'red'
            elif person._state == 'S':
                colour = 'blue'
            else:
                colour = 'grey'
            self.create_rectangle((x, y, x+10, y+10), fill=colour)
        for n in range(regions - 1):
            self.create_line(self._width / regions * (n + 1),
                             0,
                             self._width / regions * (n + 1),
                             self._height) 
