import random
from Person import Person

class Model(object):
    def __init__(self, master, speed, population,
                 infectionChance, maskWearing,
                 regions, leackage, duration, radius,
                 destinations):
        self._master = master
        self._infection_chance = infectionChance
        self._sus = 0
        self._inf = 0
        self._rec = 0
        self._rec_infections = 0
        self._long_inf = 0
        self._pre_rec = 0
        self._r_value = 0
        self._people = []
        for k in range(regions):
            xLower = int(540/regions * k)
            xUpper = int(540/regions * (k + 1))
            for n in range(int((1-leackage)*population/regions)):
                maskChance = random.uniform(0, 1)
                self._people.append(Person(random.randrange(xLower + 5, xUpper - 15),
                                           random.randrange(0, 340),
                                           random.uniform(1, 2) * speed,
                                           maskChance < maskWearing,
                                           xLower,
                                           xUpper,
                                           random.uniform(duration - duration * 0.1, duration + duration * 0.1),
                                           radius,
                                           destinations))
        for n in range(int(leackage*population)):
            maskChance = random.uniform(0, 1)
            self._people.append(Person(random.randrange(0, 540),
                                        random.randrange(0, 340),
                                        random.uniform(1, 2) * speed,
                                        maskChance < maskWearing,
                                        0,
                                        540,
                                        random.uniform(duration - duration * 0.1, duration + duration * 0.1),
                                        radius,
                                       destinations))
        self._people[0]._state = 'I'

    def move_people(self):
        self._sus = 0
        self._inf = 0
        self._rec = 0
        self._rec_infections = 0
        self._long_inf = 0
        for person in self._people:
            person.move()
            for otherPerson in self._people:
                if person != otherPerson and person._state == 'S' and otherPerson._state == 'I' and person.is_colliding(otherPerson, self._infection_chance):
                    person._state = 'I'
                    otherPerson._num_infected += 1
            if person._state == 'I':
                self._inf += 1
            elif person._state == 'S':
                self._sus += 1
            else:
                self._rec += 1
            if person._infectedTime > person._infectedDuration * 0.2 and person._state == 'I':
                self._rec_infections += person._num_infected
                self._long_inf += 1
        if (self._long_inf != 0):
            self._r_value = self._rec_infections / self._long_inf
            
    def get_people(self):
        return self._people
